package tech.harrynull.mywatcard

class PersonalInfo(val name: String)